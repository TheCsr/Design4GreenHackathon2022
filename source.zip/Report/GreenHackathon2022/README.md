# GreenHackathon2022
github repo for the green hackathon
